# Extension MBlock HC06
Extension pour le contrôle d'un module HC-06 Arduino pour l'IDE MBlock
<br />
